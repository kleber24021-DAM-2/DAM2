class step:
    def __init__(self, arrayAtom):
        self.atomArray = arrayAtom