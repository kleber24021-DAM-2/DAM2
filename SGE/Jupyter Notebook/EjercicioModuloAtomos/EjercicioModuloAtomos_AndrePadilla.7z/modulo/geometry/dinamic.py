from modulo.geometry.atom import atom
from modulo.geometry.step import step

class dinamic:
    def __init__(self):
        self.stepArray = []
        
    def loadSteps(self, filePath):
        text = open(filePath).readlines()
        actualLine = 0
        totalAtoms = int(text[actualLine])
        
        for i in range(actualLine, len(text), totalAtoms+2):
            step = self.loadStep(text, actualLine, totalAtoms)
            self.stepArray.append(step)
            actualLine = i
        
    def loadStep(self,text, actualLine, totalAtoms):
        atomArray = []
        for i in range(actualLine+2, actualLine+totalAtoms):
            line = text[i]
            line = line.rstrip()
            line = line.split()
            atomArray.append(atom(line[0], float(line[1]), float(line[2]), float(line[3])))
            
        return step(atomArray)
    
    def printAllAtoms(self):
        for step in range(len(self.stepArray)):
            print("Step número " + str(step))
            for atom in self.stepArray[step].atomArray:
                print(atom.name + " " + str(atom.x) + " " + str(atom.y) + " " + str(atom.z))