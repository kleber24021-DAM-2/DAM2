package dao.dao_implementations.file;

import dao.interfaces.DAOReviews;
import model.Review;

import java.util.List;

public class FileDaoReview implements DAOReviews {
    @Override
    public Review get(int id) {
        return null;
    }

    @Override
    public List<Review> getAll() {
        return null;
    }

    @Override
    public void save(Review t) {

    }

    @Override
    public void update(Review t) {

    }

    @Override
    public void delete(Review t) {

    }
}
