package org.quevedo.dao.interfaces;

import org.bson.Document;

public interface DaoMongo {
    void addUbicacion(Document document);
}
