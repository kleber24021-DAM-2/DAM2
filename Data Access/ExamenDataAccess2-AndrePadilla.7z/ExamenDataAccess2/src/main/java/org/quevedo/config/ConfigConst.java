package org.quevedo.config;

public class ConfigConst {
    public static final String MONGO_DB = "andre";

    private ConfigConst(){}

    public static final String URL_SQL = "jdbc:mysql://localhost:3306/UserPermissions";
    public static final String URL_MONGO = "mongodb://root:root@localhost:27017";
}
