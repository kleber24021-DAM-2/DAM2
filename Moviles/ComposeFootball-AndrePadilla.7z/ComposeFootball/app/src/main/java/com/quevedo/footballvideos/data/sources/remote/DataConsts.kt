package com.quevedo.footballvideos.data.sources.remote

object DataConsts {
    const val IO_DISPATCHER = "IoDispatcher"
    const val BASE_URL = "https://www.scorebat.com/video-api/v3/"
    const val TOKEN = "token"
    const val API_KEY = "MTQwMjZfMTY0NTM4MDA4Nl85NDRkNzhlZDQxOTY2NTZkYjZmNzdlMGFhMDFlNDhjNzBlNWEyYzIx"
}