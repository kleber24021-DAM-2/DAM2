package com.quevedo.footballvideos.ui

object Routes {
    const val MAIN = "main"
    const val DETAIL = "detail"
}