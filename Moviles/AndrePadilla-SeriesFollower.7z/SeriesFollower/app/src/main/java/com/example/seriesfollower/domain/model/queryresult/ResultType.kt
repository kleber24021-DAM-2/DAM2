package com.example.seriesfollower.domain.model.queryresult

enum class ResultType {
    MOVIE, TV
}