package com.example.seriesfollower

object GeneralConstants {
    const val NEW_WINDOW = "new_window"
    const val EMPTY_STRING = ""
    const val LOG_TAG = "OWN_ERROR:::"
    const val API_CALL_FAILED = "Api call failed"
}