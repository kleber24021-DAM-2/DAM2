package com.example.seriesfollower

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SeriesFollowerApp : Application()