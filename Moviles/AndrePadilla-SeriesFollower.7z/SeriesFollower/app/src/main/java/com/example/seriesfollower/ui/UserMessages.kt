package com.example.seriesfollower.ui

object UserMessages {
    const val DELETE = "Eliminar favorito"
    const val UNEXPECTED_DB_ERROR = "Ha surgido un error inesperado en la base de datos"
    const val LOADING = "Loading"
}