package dao.models;

public class Info {
    private String next;
    private int pages;
    private String prev;
    private int count;

    public String getNext() {
        return next;
    }

    public int getPages() {
        return pages;
    }

    public String getPrev() {
        return prev;
    }

    public int getCount() {
        return count;
    }
}
