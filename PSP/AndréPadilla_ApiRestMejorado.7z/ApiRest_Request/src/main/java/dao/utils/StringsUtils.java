package dao.utils;

public class StringsUtils {
    public static String YAML_PATH = "config/config.yaml";
    public static String PATH_BASE = "path_base";
    public static String SPANISH_FORMATTER = "EEEE dd 'de' MMMM 'de' yyyy";
}
