module common {
    requires lombok;
    exports org.quevedo.common.models;
    exports org.quevedo.common.consts;
}